// Mostrar promoción
function mostrarPromo() {
    alert("🔥 Promoción del día: 5 tacos por $80 🔥");
}

// Mostrar horario dinámico
function mostrarHorario() {
    const horario = document.getElementById("horario");
    horario.innerHTML = "⏰ Horario: Lunes a Domingo de 6:00 PM a 12:00 AM";
}
